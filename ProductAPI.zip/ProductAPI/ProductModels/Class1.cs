﻿namespace ProductModels
{
    public class Class1
    {

    }
}
